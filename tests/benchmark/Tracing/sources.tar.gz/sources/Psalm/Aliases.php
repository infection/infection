<?php
/**
 * This code is licensed under the BSD 3-Clause License.
 *
 * Copyright (c) 2017, Maks Rafalko
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 *
 * * Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

declare(strict_types=1);

namespace Psalm;

class Aliases
{
    /**
     * @var array<string, string>
     */
    public $uses;

    /**
     * @var array<string, string>
     */
    public $uses_flipped;

    /**
     * @var array<string, string>
     */
    public $functions;

    /**
     * @var array<string, string>
     */
    public $functions_flipped;

    /**
     * @var array<string, string>
     */
    public $constants;

    /**
     * @var array<string, string>
     */
    public $constants_flipped;

    /** @var string|null */
    public $namespace;

    /** @var ?int */
    public $namespace_first_stmt_start;

    /** @var ?int */
    public $uses_start;

    /** @var ?int */
    public $uses_end;

    /**
     * @param string|null $namespace
     * @param array<string, string> $uses
     * @param array<string, string> $functions
     * @param array<string, string> $constants
     * @param array<string, string> $uses_flipped
     * @param array<string, string> $functions_flipped
     * @param array<string, string> $constants_flipped
     */
    public function __construct(
        $namespace = null,
        array $uses = [],
        array $functions = [],
        array $constants = [],
        array $uses_flipped = [],
        array $functions_flipped = [],
        array $constants_flipped = []
    ) {
        $this->namespace = $namespace;
        $this->uses = $uses;
        $this->functions = $functions;
        $this->constants = $constants;
        $this->uses_flipped = $uses_flipped;
        $this->functions_flipped = $functions_flipped;
        $this->constants_flipped = $constants_flipped;
    }
}
